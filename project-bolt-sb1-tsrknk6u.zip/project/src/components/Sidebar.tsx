import { useState } from 'react';
import { ChevronDown, ChevronRight, Calculator, CreditCard, TrendingUp, Shield, Briefcase } from 'lucide-react';

interface SidebarProps {
  isDark: boolean;
  onNavigate: (page: 'home' | 'contact') => void;
}

interface Category {
  id: string;
  title: string;
  icon: React.ReactNode;
  items: string[];
}

export default function Sidebar({ isDark, onNavigate }: SidebarProps) {
  const [expandedCategories, setExpandedCategories] = useState<string[]>(['tax-salary']);

  const categories: Category[] = [
    {
      id: 'tax-salary',
      title: 'Tax & Salary',
      icon: <Calculator className="w-5 h-5" />,
      items: ['Income Tax Calc', 'HRA Exemption', 'Advance Tax', 'Gratuity Calculator', 'Bonus Calculator', 'TDS Calculator']
    },
    {
      id: 'emi-loans',
      title: 'EMI & Loans',
      icon: <CreditCard className="w-5 h-5" />,
      items: ['Home Loan EMI', 'Personal Loan EMI', 'Car Loan EMI', 'Education Loan', 'Provident Fund']
    },
    {
      id: 'investments',
      title: 'Investments',
      icon: <TrendingUp className="w-5 h-5" />,
      items: ['SIP Calculator', 'Lumpsum', 'PPF Calculator', 'NPS Calculator', 'FD Calculator', 'RD Calculator', 'CAGR Calculator', 'Goal Planning']
    },
    {
      id: 'insurance',
      title: 'Insurance & Protection',
      icon: <Shield className="w-5 h-5" />,
      items: ['Health Insurance', 'Term Insurance']
    },
    {
      id: 'gst-business',
      title: 'GST & Business',
      icon: <Briefcase className="w-5 h-5" />,
      items: ['GST Calculator', 'Break-Even Point']
    }
  ];

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev =>
      prev.includes(categoryId)
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  return (
    <div className={`fixed left-0 top-0 h-screen w-64 ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border-r overflow-y-auto transition-colors duration-300`}>
      <div className="p-6">
        <button
          onClick={() => onNavigate('home')}
          className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'} mb-2 hover:opacity-80 transition-opacity`}
        >
          VKCalc.in
        </button>
        <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Tax Calculator</p>
      </div>

      <div className="px-3 pb-6">
        <h3 className={`px-3 mb-3 text-xs font-semibold uppercase tracking-wider ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
          TOOL CATEGORIES
        </h3>

        {categories.map((category) => {
          const isExpanded = expandedCategories.includes(category.id);

          return (
            <div key={category.id} className="mb-1">
              <button
                onClick={() => toggleCategory(category.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-all duration-200 ${
                  isDark
                    ? 'hover:bg-gray-700 text-gray-200'
                    : 'hover:bg-gray-100 text-gray-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  {category.icon}
                  <span className="font-medium">{category.title}</span>
                </div>
                {isExpanded ? (
                  <ChevronDown className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </button>

              {isExpanded && (
                <div className="mt-1 ml-6 space-y-1">
                  {category.items.map((item) => (
                    <button
                      key={item}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-all duration-200 ${
                        isDark
                          ? 'hover:bg-gray-700 text-gray-300'
                          : 'hover:bg-gray-50 text-gray-600'
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
