import { Calculator, Home, CreditCard, GraduationCap, PiggyBank, TrendingUp, Percent, DollarSign, Shield, FileText, Tag } from 'lucide-react';

interface CalculatorGridProps {
  isDark: boolean;
}

interface CalculatorCard {
  icon: React.ReactNode;
  title: string;
  description: string;
  color: string;
}

export default function CalculatorGrid({ isDark }: CalculatorGridProps) {
  const sections = [
    {
      id: 'tax-salary',
      title: 'Tax & Salary',
      icon: <Calculator className="w-5 h-5" />,
      cards: [
        { icon: <Calculator className="w-6 h-6" />, title: 'Income Tax Calc', description: 'Calculate income tax obligation for AY 2024-25', color: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400' },
        { icon: <Home className="w-6 h-6" />, title: 'HRA Exemption', description: 'Calculate your HRA allowance and benefits', color: 'bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400' },
        { icon: <DollarSign className="w-6 h-6" />, title: 'Advance Tax', description: 'Calculate advance tax for payments', color: 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' },
        { icon: <PiggyBank className="w-6 h-6" />, title: 'Gratuity Calculator', description: 'Calculate your gratuity payment', color: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400' },
        { icon: <Tag className="w-6 h-6" />, title: 'Bonus Calculator', description: 'Calculate statutory bonus as per law', color: 'bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400' },
        { icon: <Percent className="w-6 h-6" />, title: 'TDS Calculator', description: 'Tax Deducted at Source calculator', color: 'bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400' }
      ]
    },
    {
      id: 'emi-loans',
      title: 'EMI & Loans',
      icon: <CreditCard className="w-5 h-5" />,
      cards: [
        { icon: <Home className="w-6 h-6" />, title: 'Home Loan EMI', description: 'EMI calculator for home loans', color: 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' },
        { icon: <CreditCard className="w-6 h-6" />, title: 'Personal Loan EMI', description: 'Calculate EMI rates and tenure options', color: 'bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400' },
        { icon: <CreditCard className="w-6 h-6" />, title: 'Car Loan EMI', description: 'Plan your vehicle purchase', color: 'bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400' },
        { icon: <GraduationCap className="w-6 h-6" />, title: 'Education Loan', description: 'Calculate education loan EMI', color: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400' },
        { icon: <PiggyBank className="w-6 h-6" />, title: 'Provident Fund', description: 'PF maturity and withdrawal calculator', color: 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' }
      ]
    },
    {
      id: 'investments',
      title: 'Investments',
      icon: <TrendingUp className="w-5 h-5" />,
      cards: [
        { icon: <TrendingUp className="w-6 h-6" />, title: 'SIP Calculator', description: 'Systematic Investment Plan for 10-30 years', color: 'bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400' },
        { icon: <DollarSign className="w-6 h-6" />, title: 'Lumpsum', description: 'Calculate returns on one-time investment', color: 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' },
        { icon: <PiggyBank className="w-6 h-6" />, title: 'PPF Calculator', description: 'Public Provident Fund investments', color: 'bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400' },
        { icon: <TrendingUp className="w-6 h-6" />, title: 'NPS Calculator', description: 'National Pension Scheme returns', color: 'bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400' },
        { icon: <DollarSign className="w-6 h-6" />, title: 'Sukanya Samriddhi', description: 'Girl child savings scheme calculator', color: 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' },
        { icon: <Calculator className="w-6 h-6" />, title: 'FD Calculator', description: 'Fixed Deposit Maturity Amount', color: 'bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400' },
        { icon: <PiggyBank className="w-6 h-6" />, title: 'CAGR Calculator', description: 'Compound Annual Growth Rate', color: 'bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400' },
        { icon: <TrendingUp className="w-6 h-6" />, title: 'Goal Planning', description: 'Plan investments for future goals', color: 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' }
      ]
    },
    {
      id: 'insurance',
      title: 'Insurance & Protection',
      icon: <Shield className="w-5 h-5" />,
      cards: [
        { icon: <Shield className="w-6 h-6" />, title: 'Health Insurance', description: 'Compare premiums and find best coverage', color: 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' },
        { icon: <Shield className="w-6 h-6" />, title: 'Term Insurance', description: 'Calculate adequate life cover needed', color: 'bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400' }
      ]
    },
    {
      id: 'gst-business',
      title: 'GST & Business',
      icon: <FileText className="w-5 h-5" />,
      cards: [
        { icon: <Percent className="w-6 h-6" />, title: 'GST Calculator', description: 'Quickly calculate GST & prices', color: 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' },
        { icon: <TrendingUp className="w-6 h-6" />, title: 'Break-Even Point', description: 'Calculate business profitability threshold', color: 'bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400' }
      ]
    }
  ];

  return (
    <main className="max-w-7xl mx-auto px-6 py-12">
      <div className="text-center mb-16">
        <h1 className={`text-5xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
          SMART FINANCIAL TOOLS
        </h1>
        <p className={`text-lg ${isDark ? 'text-gray-400' : 'text-gray-600'} max-w-3xl mx-auto`}>
          Comprehensive financial calculators for Income Tax, Salary, SIP, EMI, and Provident Loans. Built with precision by tax experts at VK Tax.
        </p>
        <div className={`mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-full ${isDark ? 'bg-yellow-900/30 text-yellow-400' : 'bg-yellow-50 text-yellow-700'}`}>
          <span className="text-sm font-medium">FOLLOW US ON SOCIAL</span>
        </div>
      </div>

      {sections.map((section) => (
        <section key={section.id} className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <div className={`p-2 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-100'}`}>
              {section.icon}
            </div>
            <h2 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
              {section.title}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {section.cards.map((card, index) => (
              <button
                key={index}
                className={`p-6 rounded-xl ${
                  isDark ? 'bg-gray-800 hover:bg-gray-750 border-gray-700' : 'bg-white hover:shadow-xl'
                } border transition-all duration-300 text-left group`}
              >
                <div className={`w-12 h-12 rounded-lg ${card.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  {card.icon}
                </div>
                <h3 className={`text-lg font-semibold mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  {card.title}
                </h3>
                <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'} mb-4`}>
                  {card.description}
                </p>
                <span className={`text-sm font-medium ${isDark ? 'text-blue-400' : 'text-blue-600'} group-hover:underline`}>
                  USE TOOL →
                </span>
              </button>
            ))}
          </div>
        </section>
      ))}
    </main>
  );
}
