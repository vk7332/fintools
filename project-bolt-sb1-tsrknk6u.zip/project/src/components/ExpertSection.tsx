interface ExpertSectionProps {
  isDark: boolean;
  onContactClick: () => void;
}

export default function ExpertSection({ isDark, onContactClick }: ExpertSectionProps) {
  return (
    <section className="max-w-7xl mx-auto px-6 py-12 mb-12">
      <div className={`rounded-2xl overflow-hidden ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-gradient-to-r from-blue-50 to-sky-50'} border p-8 md:p-12`}>
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="w-32 h-32 md:w-40 md:h-40 rounded-full overflow-hidden flex-shrink-0 shadow-xl">
            <img
              src="https://images.pexels.com/photos/5668838/pexels-photo-5668838.jpeg?auto=compress&cs=tinysrgb&w=400"
              alt="Tax Expert"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="flex-1 text-center md:text-left">
            <h2 className={`text-3xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Expert Guidance by <span className="text-blue-600">VK Tax</span>
            </h2>
            <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-700'} mb-6 leading-relaxed`}>
              Looking for a trusted CA to simplify financial compliance for you?
              We work with a network of verified Chartered Accountants who can provide peace of mind.
            </p>

            <div className="flex flex-wrap gap-4 justify-center md:justify-start">
              <button
                onClick={onContactClick}
                className="px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-semibold transition-all duration-200 shadow-md hover:shadow-lg"
              >
                ITR FILING
              </button>
              <button
                onClick={onContactClick}
                className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white rounded-lg font-semibold transition-all duration-200 shadow-md hover:shadow-lg"
              >
                TAX ADVISORY
              </button>
              <button
                onClick={onContactClick}
                className="px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg font-semibold transition-all duration-200 shadow-md hover:shadow-lg"
              >
                GST COMPLIANCE
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
