interface HeaderProps {
  isDark: boolean;
  onNavigate: (page: 'home' | 'contact') => void;
}

export default function Header({ isDark, onNavigate }: HeaderProps) {
  return (
    <header className={`${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border-b transition-colors duration-300`}>
      <div className="max-w-7xl mx-auto px-6 py-4">
        <nav className="flex items-center justify-between">
          <div className="flex items-center gap-8">
            <button
              onClick={() => onNavigate('home')}
              className={`font-semibold ${isDark ? 'text-white hover:text-gray-300' : 'text-gray-900 hover:text-gray-600'} transition-colors`}
            >
              Home
            </button>
            <button
              className={`font-semibold ${isDark ? 'text-gray-400 hover:text-gray-300' : 'text-gray-600 hover:text-gray-900'} transition-colors`}
            >
              Calculators
            </button>
            <button
              className={`font-semibold ${isDark ? 'text-gray-400 hover:text-gray-300' : 'text-gray-600 hover:text-gray-900'} transition-colors`}
            >
              Tax Forms
            </button>
            <button
              className={`font-semibold ${isDark ? 'text-gray-400 hover:text-gray-300' : 'text-gray-600 hover:text-gray-900'} transition-colors`}
            >
              Tax Books
            </button>
            <button
              className={`font-semibold ${isDark ? 'text-gray-400 hover:text-gray-300' : 'text-gray-600 hover:text-gray-900'} transition-colors`}
            >
              Blog
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className={`font-semibold ${isDark ? 'text-gray-400 hover:text-gray-300' : 'text-gray-600 hover:text-gray-900'} transition-colors`}
            >
              Contact
            </button>
          </div>

          <button className="px-5 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-semibold transition-all duration-200 shadow-md hover:shadow-lg">
            File ITR
          </button>
        </nav>
      </div>
    </header>
  );
}
