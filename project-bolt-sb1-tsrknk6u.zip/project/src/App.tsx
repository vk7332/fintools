import { useState } from 'react';
import { Sun, Moon } from 'lucide-react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import CalculatorGrid from './components/CalculatorGrid';
import ExpertSection from './components/ExpertSection';
import ContactPage from './components/ContactPage';

function App() {
  const [isDark, setIsDark] = useState(false);
  const [currentPage, setCurrentPage] = useState<'home' | 'contact'>('home');

  return (
    <div className={isDark ? 'dark' : ''}>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
        <div className="flex">
          <Sidebar isDark={isDark} onNavigate={setCurrentPage} />

          <div className="flex-1 ml-64">
            <Header isDark={isDark} onNavigate={setCurrentPage} />

            <button
              onClick={() => setIsDark(!isDark)}
              className="fixed top-4 right-4 z-50 p-3 rounded-full bg-white dark:bg-gray-800 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200 dark:border-gray-700"
              aria-label="Toggle dark mode"
            >
              {isDark ? (
                <Sun className="w-5 h-5 text-yellow-500" />
              ) : (
                <Moon className="w-5 h-5 text-gray-700" />
              )}
            </button>

            {currentPage === 'home' ? (
              <>
                <CalculatorGrid isDark={isDark} />
                <ExpertSection isDark={isDark} onContactClick={() => setCurrentPage('contact')} />
              </>
            ) : (
              <ContactPage isDark={isDark} onBackClick={() => setCurrentPage('home')} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
